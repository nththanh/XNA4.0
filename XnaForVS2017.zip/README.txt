Run all of the following commands in order:
1. Install DirectX
2. Install XNA Framework 4.0 Redistribution
3. Install XNA Game Studio 4.0 Platform Tools
4. Install XNA Game Studio 4.0 Shared
5. Install XNA Game Studio 4.0.vsix

cd C:\Program Files (x86)\Microsoft Visual Studio\2017\Community\MSBuild\15.0\Bin
gacutil /i Microsoft.Build.Framework.dll
gacutil /i Microsoft.Build.dll